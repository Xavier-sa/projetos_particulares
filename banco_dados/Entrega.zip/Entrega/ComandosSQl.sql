           -- ## Úteis -
-- renomear banco Dados:

CREATE DATABASE trabalho / DROP DATABASE aula_db


-- Exibir todas as tabelas
SHOW TABLES;


-- comando para deletar TABLES
drop table marcas;
drop table carros;
drop table pessoas ;
DROP TABLE carros_pessoas;
## -- atençao 

 -- Deletar meu banco aula_db
drop database aula_db;

--  resumo
SELECT- extrai dados de um banco de dados
UPDATE- atualiza dados em um banco de dados
DELETE- exclui dados de um banco de dados
INSERT INTO- insere novos dados em um banco de dados
CREATE DATABASE- cria um novo banco de dados
ALTER DATABASE- modifica um banco de dados
CREATE TABLE- cria uma nova tabela
ALTER TABLE- modifica uma tabela
DROP TABLE- apaga uma tabela
CREATE INDEX- cria um índice (chave de pesquisa)
DROP INDEX- exclui um índice

