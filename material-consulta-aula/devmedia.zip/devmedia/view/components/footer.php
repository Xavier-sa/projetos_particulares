<?php require_once __DIR__ . '/../../config/env.php'; ?>

<footer class="footer">
    <span>Devmedia - <?= date('Y') ?> - <?= APP_CONSTANTS['APP_VERSION'] ?></span>
</footer>